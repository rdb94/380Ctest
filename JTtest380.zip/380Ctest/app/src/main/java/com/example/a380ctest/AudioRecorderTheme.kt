package com.example.a380ctest

class AudioRecorderTheme(function: () -> Unit) {

}
