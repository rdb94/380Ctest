/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: analyse_periodecity_internal_types.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 10-Mar-2025 15:14:10
 */

#ifndef ANALYSE_PERIODECITY_INTERNAL_TYPES_H
#define ANALYSE_PERIODECITY_INTERNAL_TYPES_H

/* Include Files */
#include "analyse_periodecity_types.h"
#include "rtwtypes.h"

/* Type Definitions */
#ifndef c_typedef_coder_internal_Sorted
#define c_typedef_coder_internal_Sorted
typedef struct {
  double buf[3];
  int nbuf;
  int nnans;
} coder_internal_SortedBuffer;
#endif /* c_typedef_coder_internal_Sorted */

#endif
/*
 * File trailer for analyse_periodecity_internal_types.h
 *
 * [EOF]
 */
