/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: analyse_periodecity_terminate.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 10-Mar-2025 15:14:10
 */

#ifndef ANALYSE_PERIODECITY_TERMINATE_H
#define ANALYSE_PERIODECITY_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void analyse_periodecity_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for analyse_periodecity_terminate.h
 *
 * [EOF]
 */
