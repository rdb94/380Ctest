/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: logspace.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 10-Mar-2025 15:14:10
 */

#ifndef LOGSPACE_H
#define LOGSPACE_H

/* Include Files */
#include "analyse_periodecity_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void logspace(double d2, double n, emxArray_real_T *y);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for logspace.h
 *
 * [EOF]
 */
