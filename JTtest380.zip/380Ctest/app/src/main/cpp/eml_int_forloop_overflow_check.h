/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: eml_int_forloop_overflow_check.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 10-Mar-2025 15:14:10
 */

#ifndef EML_INT_FORLOOP_OVERFLOW_CHECK_H
#define EML_INT_FORLOOP_OVERFLOW_CHECK_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void check_forloop_overflow_error(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for eml_int_forloop_overflow_check.h
 *
 * [EOF]
 */
