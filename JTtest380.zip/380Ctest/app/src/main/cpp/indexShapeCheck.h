/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: indexShapeCheck.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 10-Mar-2025 15:14:10
 */

#ifndef INDEXSHAPECHECK_H
#define INDEXSHAPECHECK_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void indexShapeCheck(int matrixSize, const int indexSize[2]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for indexShapeCheck.h
 *
 * [EOF]
 */
