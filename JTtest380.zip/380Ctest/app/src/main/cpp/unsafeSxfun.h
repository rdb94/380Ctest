/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: unsafeSxfun.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 10-Mar-2025 15:14:10
 */

#ifndef UNSAFESXFUN_H
#define UNSAFESXFUN_H

/* Include Files */
#include "analyse_periodecity_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void binary_expand_op_11(emxArray_real_T *in1, const double in3[20000], int in4,
                         int in5, const emxArray_real_T *in6);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for unsafeSxfun.h
 *
 * [EOF]
 */
