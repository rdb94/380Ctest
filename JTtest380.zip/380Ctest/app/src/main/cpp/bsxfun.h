/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 * File: bsxfun.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 10-Mar-2025 15:14:10
 */

#ifndef BSXFUN_H
#define BSXFUN_H

/* Include Files */
#include "analyse_periodecity_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_bsxfun(const emxArray_creal_T *a, const emxArray_creal_T *b,
              emxArray_creal_T *c);

void bsxfun(const emxArray_real_T *a, const emxArray_real_T *b,
            emxArray_real_T *c);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for bsxfun.h
 *
 * [EOF]
 */
